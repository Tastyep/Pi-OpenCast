const STORAGE_KEYS = {
  API_IP: "apiIp",
  WEB_APP_IP: "webAppIp",
  OPT_CAST_VIDEO: "optCastVideo",
};

const API_IP = "192.168.178.74:2020";
const WEB_APP_IP = "192.168.178.74:8081";

export { STORAGE_KEYS, API_IP, WEB_APP_IP };
